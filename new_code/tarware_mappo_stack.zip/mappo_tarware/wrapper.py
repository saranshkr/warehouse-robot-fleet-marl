from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np

def _require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)

def _flatten_obs(x: Any) -> np.ndarray:
    try:
        arr = np.asarray(x, dtype=np.float32).ravel()
    except Exception as e:
        raise TypeError(f"Observation could not be converted to float32 array. type={type(x)}") from e
    if arr.ndim != 1:
        arr = arr.reshape(-1).astype(np.float32)
    return arr

def _is_dict_like(x: Any) -> bool:
    return hasattr(x, "keys") and hasattr(x, "__getitem__")

@dataclass
class WrapperSpecs:
    num_agents: int
    obs_dim: int
    act_dim: int
    agent_ids: List[str]
    role_ids: Optional[np.ndarray]  # shape [N], int64

class TARWareTensorWrapper:
    """
    Minimal tensor-friendly wrapper for TA-RWARE (Gymnasium multi-agent).
    Outputs numpy arrays; training code converts to torch tensors.

    API:
      reset() -> obs: [N, obs_dim] float32
      step(actions: [N] int64) -> (obs, rewards, done, info)

    Reward:
      - per_agent: [N]
      - team_sum/team_mean: scalar stored as info["team_reward"] and returned rewards shaped [N] (all same),
        so downstream code can stay consistent (always [N]).
    """

    def __init__(
        self,
        env,
        *,
        reward_mode: str = "team_sum",
        use_role_id: bool = True,
        explicit_agent_ids: Optional[Sequence[str]] = None,
        explicit_role_ids: Optional[Sequence[int]] = None,
    ) -> None:
        self.env = env
        self.reward_mode = reward_mode
        _require(reward_mode in {"per_agent", "team_sum", "team_mean"}, "reward_mode must be per_agent|team_sum|team_mean")

        self._agent_ids: List[str] = []
        self._agent_index: Dict[str, int] = {}
        self._role_ids: Optional[np.ndarray] = None
        self._episode_step = 0

        self._init_agent_order(explicit_agent_ids)
        self._obs_dim = self._infer_obs_dim()
        self._act_dim = self._infer_act_dim()

        if use_role_id:
            self._role_ids = self._infer_role_ids(explicit_role_ids)

        self._specs = WrapperSpecs(
            num_agents=len(self._agent_ids),
            obs_dim=int(self._obs_dim),
            act_dim=int(self._act_dim),
            agent_ids=list(self._agent_ids),
            role_ids=None if self._role_ids is None else self._role_ids.copy(),
        )

    def get_specs(self) -> WrapperSpecs:
        return self._specs

    def seed(self, seed: int) -> None:
        try:
            self.env.reset(seed=int(seed))
        except TypeError:
            # Some envs only accept seed via env.seed or similar
            if hasattr(self.env, "seed"):
                self.env.seed(int(seed))
            else:
                raise RuntimeError("Env does not support seeding via reset(seed=...) or env.seed().")

    # ---------- Gym API adapters ----------

    def reset(self, *, seed: Optional[int] = None) -> np.ndarray:
        self._episode_step = 0
        if seed is not None:
            self.seed(int(seed))

        out = self.env.reset()
        obs = out[0] if isinstance(out, tuple) and len(out) >= 1 else out
        obs_tensor = self._obs_to_tensor(obs)
        return obs_tensor

    def step(self, action_tensor: np.ndarray) -> Tuple[np.ndarray, np.ndarray, bool, Dict[str, Any]]:
        actions = self._actions_from_tensor(action_tensor)
        out = self.env.step(actions)

        # Gymnasium: (obs, reward, terminated, truncated, info)
        # Classic gym: (obs, reward, done, info)
        if not isinstance(out, tuple):
            raise RuntimeError(f"Env.step returned non-tuple type {type(out)}; expected Gym step tuple.")
        if len(out) == 5:
            obs, rew, terminated, truncated, info = out
            done = bool(terminated) or bool(truncated)
        elif len(out) == 4:
            obs, rew, done, info = out
            done = bool(done)
        else:
            raise RuntimeError(f"Env.step returned tuple of len={len(out)}; expected 4 or 5.")

        self._episode_step += 1
        obs_tensor = self._obs_to_tensor(obs)
        rew_vec = self._reward_to_vector(rew)

        info = dict(info or {})
        info.setdefault("episode_step", self._episode_step)
        info.setdefault("agent_ids", list(self._agent_ids))
        if self._role_ids is not None:
            info.setdefault("role_ids", self._role_ids.copy())

        # Optional TA-RWARE metrics (if env provides them)
        for k in ("deliveries_completed", "requested_deliveries_completed", "picker_assists", "invalid_actions_count", "collisions"):
            if k in info:
                continue
            v = getattr(self.env, k, None)
            if v is not None:
                info[k] = v

        # Always include team reward if we computed it
        if self.reward_mode in {"team_sum", "team_mean"}:
            info["team_reward"] = float(np.mean(rew_vec)) if self.reward_mode == "team_mean" else float(np.sum(rew_vec))

        return obs_tensor, rew_vec.astype(np.float32), done, info

    # ---------- Internals ----------

    def _init_agent_order(self, explicit_agent_ids: Optional[Sequence[str]]) -> None:
        if explicit_agent_ids is not None:
            ids = [str(x) for x in explicit_agent_ids]
        elif hasattr(self.env, "agents") and isinstance(getattr(self.env, "agents"), (list, tuple)):
            ids = [str(x) for x in getattr(self.env, "agents")]
        else:
            # Try probing reset() to infer agent count and assign stable names.
            out = self.env.reset()
            obs = out[0] if isinstance(out, tuple) and len(out) >= 1 else out
            if _is_dict_like(obs):
                ids = sorted([str(k) for k in obs.keys()])
            elif isinstance(obs, (list, tuple)):
                ids = [f"agent_{i}" for i in range(len(obs))]
            else:
                # single-agent fallback
                ids = ["agent_0"]

        _require(len(ids) > 0, "Could not infer agent ids; env returned zero agents.")
        self._agent_ids = list(ids)
        self._agent_index = {aid: i for i, aid in enumerate(self._agent_ids)}

    def _infer_obs_dim(self) -> int:
        out = self.env.reset()
        obs = out[0] if isinstance(out, tuple) and len(out) >= 1 else out

        vecs = self._obs_to_list(obs)
        dims = [v.size for v in vecs]
        _require(all(d > 0 for d in dims), f"Invalid observation dims: {dims}")
        return int(max(dims))

    def _infer_act_dim(self) -> int:
        asp = getattr(self.env, "action_space", None)
        if asp is None:
            raise AttributeError("Env has no action_space; cannot infer action dim.")

        # Common cases: Discrete, Tuple[Discrete]*N, Dict of agent->Discrete
        if hasattr(asp, "n"):
            return int(asp.n)

        if hasattr(asp, "spaces"):
            spaces = asp.spaces
            if isinstance(spaces, (list, tuple)):
                ns = []
                for s in spaces:
                    if not hasattr(s, "n"):
                        raise TypeError(f"Expected Discrete in action_space tuple; got {type(s)}")
                    ns.append(int(s.n))
                return int(max(ns))
            if isinstance(spaces, dict):
                ns = []
                for s in spaces.values():
                    if not hasattr(s, "n"):
                        raise TypeError(f"Expected Discrete in action_space dict; got {type(s)}")
                    ns.append(int(s.n))
                return int(max(ns))

        raise NotImplementedError(f"Unsupported action_space type: {type(asp)}. Expected Discrete or Tuple/Dict of Discrete.")

    def _infer_role_ids(self, explicit_role_ids: Optional[Sequence[int]]) -> Optional[np.ndarray]:
        n = len(self._agent_ids)
        if explicit_role_ids is not None:
            _require(len(explicit_role_ids) == n, f"explicit_role_ids must have len={n}")
            arr = np.asarray(explicit_role_ids, dtype=np.int64)
            return arr

        # Heuristic: parse agent id strings
        role = np.zeros((n,), dtype=np.int64)
        for i, aid in enumerate(self._agent_ids):
            low = aid.lower()
            if "picker" in low:
                role[i] = 1
            elif "agv" in low or "robot" in low:
                role[i] = 0
            else:
                role[i] = 0
        return role

    def _obs_to_list(self, obs: Any) -> List[np.ndarray]:
        # Dict: use agent ids ordering
        if _is_dict_like(obs):
            missing = [aid for aid in self._agent_ids if aid not in obs]
            if missing:
                raise KeyError(f"Obs dict missing agent keys: {missing}. Got keys={list(obs.keys())}")
            vecs = [_flatten_obs(obs[aid]) for aid in self._agent_ids]
            return vecs

        if isinstance(obs, (list, tuple)):
            if len(obs) != len(self._agent_ids):
                # allow env.agent list mismatch; but require same length
                raise ValueError(f"Obs list/tuple len={len(obs)} != num_agents={len(self._agent_ids)}")
            return [_flatten_obs(x) for x in obs]

        # Single-agent
        return [_flatten_obs(obs)]

    def _obs_to_tensor(self, obs: Any) -> np.ndarray:
        vecs = self._obs_to_list(obs)
        maxd = self._obs_dim
        out = np.zeros((len(vecs), maxd), dtype=np.float32)
        for i, v in enumerate(vecs):
            out[i, : v.size] = v
        return out

    def _actions_from_tensor(self, action_tensor: np.ndarray) -> Any:
        if not isinstance(action_tensor, np.ndarray):
            action_tensor = np.asarray(action_tensor)
        _require(action_tensor.dtype in (np.int64, np.int32, np.int16, np.int8), f"actions must be integer dtype, got {action_tensor.dtype}")
        action_tensor = action_tensor.reshape(-1)
        _require(action_tensor.shape[0] == len(self._agent_ids), f"actions shape must be [N={len(self._agent_ids)}], got {action_tensor.shape}")

        asp = getattr(self.env, "action_space", None)
        if asp is None:
            # fallback to list
            return [int(a) for a in action_tensor.tolist()]

        if hasattr(asp, "spaces"):
            spaces = asp.spaces
            if isinstance(spaces, dict):
                return {aid: int(action_tensor[self._agent_index[aid]]) for aid in self._agent_ids}

        # Default: list/tuple
        return [int(a) for a in action_tensor.tolist()]

    def _reward_to_vector(self, rew: Any) -> np.ndarray:
        n = len(self._agent_ids)
        if _is_dict_like(rew):
            missing = [aid for aid in self._agent_ids if aid not in rew]
            if missing:
                raise KeyError(f"Reward dict missing agent keys: {missing}. Got keys={list(rew.keys())}")
            vec = np.asarray([float(rew[aid]) for aid in self._agent_ids], dtype=np.float32)
        elif isinstance(rew, (list, tuple, np.ndarray)):
            if len(rew) != n:
                raise ValueError(f"Reward sequence len={len(rew)} != num_agents={n}")
            vec = np.asarray(rew, dtype=np.float32).reshape(n)
        else:
            # scalar reward (team already)
            vec = np.full((n,), float(rew), dtype=np.float32)

        if self.reward_mode == "per_agent":
            return vec

        # team reward computed but we keep [N] rewards for simpler PPO shaping
        team = float(np.sum(vec)) if self.reward_mode == "team_sum" else float(np.mean(vec))
        return np.full((n,), team, dtype=np.float32)
