from __future__ import annotations

import csv
import json
import os
import time
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Dict, Optional

class MetricsLogger:
    def __init__(self, run_dir: Path, use_tensorboard: bool = True) -> None:
        self.run_dir = Path(run_dir)
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.csv_path = self.run_dir / "metrics.csv"
        self._csv_file = open(self.csv_path, "a", newline="")
        self._writer: Optional[csv.DictWriter] = None

        self.tb = None
        if use_tensorboard:
            try:
                from torch.utils.tensorboard import SummaryWriter
                self.tb = SummaryWriter(log_dir=str(self.run_dir / "tb"))
            except Exception:
                self.tb = None

    def write_hparams(self, cfg: Dict[str, Any]) -> None:
        (self.run_dir / "config.json").write_text(json.dumps(cfg, indent=2, sort_keys=True))

    def log(self, step: int, metrics: Dict[str, Any]) -> None:
        row = {"step": int(step), "time": time.time()}
        row.update(metrics)

        if self._writer is None:
            self._writer = csv.DictWriter(self._csv_file, fieldnames=list(row.keys()))
            if self._csv_file.tell() == 0:
                self._writer.writeheader()

        # ensure consistent columns
        for k in row.keys():
            if k not in self._writer.fieldnames:
                # recreate writer with new columns
                fieldnames = list(dict.fromkeys(list(self._writer.fieldnames) + [k]))
                self._writer = csv.DictWriter(self._csv_file, fieldnames=fieldnames)
                if self._csv_file.tell() == 0:
                    self._writer.writeheader()
                break

        self._writer.writerow(row)
        self._csv_file.flush()

        if self.tb is not None:
            for k, v in metrics.items():
                if isinstance(v, (int, float)):
                    self.tb.add_scalar(k, v, global_step=step)

    def close(self) -> None:
        if self.tb is not None:
            self.tb.close()
        self._csv_file.close()

def make_run_dir(root: str, experiment: str) -> Path:
    ts = time.strftime("%Y%m%d_%H%M%S")
    return Path(root) / experiment / ts

def save_text(run_dir: Path, name: str, text: str) -> None:
    (Path(run_dir) / name).write_text(text)

def save_json(run_dir: Path, name: str, data: Dict[str, Any]) -> None:
    (Path(run_dir) / name).write_text(json.dumps(data, indent=2, sort_keys=True))
